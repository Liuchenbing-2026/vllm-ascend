#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PY'
from pathlib import Path
import base64,collections,csv,gzip,hashlib,json,math,statistics
root=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/v31_operator_remeasurement_20260913')
out=root/'run_A1'
assert all((out/n).read_text().strip()=='0' for n in ['timing.rc','profile.rc','run.rc','postflight.rc','controller.rc'])
manifest=json.loads((root/'manifest.json').read_text())
for name,sha in manifest['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
complete={phase:[json.loads((out/phase/('complete_rank%d.json'%rank)).read_text()) for rank in range(4)] for phase in ['timing','profile']}
assert all(x['status']=='V31_OPERATOR_COMPLETE' for rows in complete.values() for x in rows)
records=[];comparisons=[];files=[]
for scope in manifest['scopes']:
    for tokens in manifest['input_tokens']:
        rows=[]
        for rank in range(4):
            p=out/'timing'/('%s_%d_rank%d.json'%(scope,tokens,rank))
            row=json.loads(p.read_text());rows.append(row);records.append(row)
            files.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
            assert row['reference_difference']['bitwise_equal'] and row['rank']==rank
            assert row['async_repeats_each_arm']==20
        assert len({r['input_sha256'] for r in rows})==1,'RANK_INPUTS_DIFFER'
        blocks=[]
        for block in range(4):
            label=rows[0]['blocks'][block]['label']
            assert all(r['blocks'][block]['label']==label and len(r['blocks'][block]['samples_ms'])==30 for r in rows)
            slowest=[max(r['blocks'][block]['samples_ms'][i] for r in rows) for i in range(30)]
            assert all(math.isfinite(v) and v>0 for v in slowest)
            blocks.append(dict(label=label,slowest_rank_median_ms=statistics.median(slowest),
                               rank_medians_ms=[statistics.median(r['blocks'][block]['samples_ms']) for r in rows]))
        off=statistics.mean(blocks[i]['slowest_rank_median_ms'] for i in [0,3])
        on=statistics.mean(blocks[i]['slowest_rank_median_ms'] for i in [1,2])
        comparisons.append(dict(scope=scope,tokens=tokens,off_ms=off,on_ms=on,latency_change_percent=(on/off-1)*100,
                                pair_changes_percent=[(blocks[b]['slowest_rank_median_ms']/blocks[a]['slowest_rank_median_ms']-1)*100 for a,b in [(0,1),(3,2)]],blocks=blocks))
native=[]
captures=sorted((out/'msprof').glob('PROF_*'))
assert len(captures)==4,('NATIVE_CAPTURE_COUNT',len(captures))
seen=set()
for capture in captures:
    entries={};devices=set()
    paths=sorted(capture.glob('mindstudio_profiler_output/op_summary_*.csv'))
    assert paths,('NATIVE_EXPORT_MISSING',str(capture))
    for path in paths:
        files.append(dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        with path.open() as f:
            for row in csv.DictReader(f):
                devices.add(int(row['Device_id']))
                key=tuple(row[k] for k in ['Task ID','Stream ID','Task Start Time(us)','Op Name'])
                if key in entries:assert entries[key]==row
                entries[key]=row
    assert len(devices)==1
    device=devices.pop();assert device not in seen;seen.add(device)
    tasks=[];shapes=[];shape_map={};groups=collections.defaultdict(list)
    for row in sorted(entries.values(),key=lambda x:float(x['Task Start Time(us)'])):
        descriptor=tuple(row[k] for k in ['OP Type','Task Type','Input Shapes','Input Data Types','Output Shapes'])
        if descriptor not in shape_map:
            shape_map[descriptor]=len(shapes)
            shapes.append(dict(id=len(shapes),op=descriptor[0],task_type=descriptor[1],input_shapes=descriptor[2],input_types=descriptor[3],output_shapes=descriptor[4]))
        start=float(row['Task Start Time(us)']);duration=float(row['Task Duration(us)'])
        assert math.isfinite(start) and math.isfinite(duration) and duration>=0
        shape_id=shape_map[descriptor];groups[shape_id].append(duration)
        tasks.append(dict(start_us=start,duration_us=duration,shape_id=shape_id,stream_id=row['Stream ID'],task_id=row['Task ID'],op_name=row['Op Name']))
    for shape in shapes:
        values=groups[shape['id']];shape.update(count=len(values),median_us=statistics.median(values))
    native.append(dict(device=device,capture=str(capture),shapes=shapes,tasks=tasks))
assert seen=={0,1,2,3}
result=dict(status='V31_OPERATOR_RAW_RESULTS_COLLECTED',manifest=manifest,complete=complete,
            comparisons=comparisons,timing_records=records,native=native,files=files,
            scope='Same exact accepted V31 runtime and V30 kernel; random synthetic tensors, no shared expert compute or model scheduling. Profiled timing is diagnostic, not the unprofiled acceptance.',
            native_selection='Per shape and arm: 1 reference + 20 queued stability + 10 warm/10 sample + 10 warm/10 sample = 61 calls. Timed indices 31..40 and 51..60, zero-based.')
raw=(json.dumps(result,separators=(',',':'))+'\n').encode()
saved=root/'operator_raw_results.json'
assert not saved.exists(),'DO_NOT_OVERWRITE_RESULT'
saved.write_bytes(raw)
for row in comparisons:print('OPERATOR_UNPROFILED_SUMMARY',json.dumps({k:v for k,v in row.items() if k!='blocks'}))
print('V31_OPERATOR_RESULTS_JSON',base64.b64encode(gzip.compress(raw)).decode(),flush=True)
print('V31_OPERATOR_OBSERVATION',json.dumps(dict(controller_rc=0,postflight_rc=0,raw_result=str(saved),raw_sha256=hashlib.sha256(raw).hexdigest())),flush=True)
PY
