#!/usr/bin/env bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_e2e_20260907/v31_operator_remeasurement_20260913
guard=/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap/preflight_devices.py
test "$(cat "$task/static.rc")" = 0
exec 9>/var/lock/megamoe_q36.lock
flock -n 9
docker exec mm_bf16_serve_20260907 python3 "$guard"
out=$task/run_A1
test ! -e "$out"
mkdir "$out"
exec > "$out/run.log" 2>&1
printf '%s
' "$$" > "$out/launcher.pid"
cat /proc/$$/stat > "$out/launcher.initial_stat"
on_exit() {
  rc=$?
  trap - EXIT
  set +e
  printf '%s
' "$rc" > "$out/run.rc"
  docker exec mm_bf16_serve_20260907 python3 "$guard" > "$out/postflight.log" 2>&1
  post_rc=$?
  printf '%s
' "$post_rc" > "$out/postflight.rc"
  if test "$rc" = 0 && test "$post_rc" != 0; then rc=$post_rc; fi
  printf '%s
' "$rc" > "$out/controller.rc"
  exit "$rc"
}
trap on_exit EXIT
docker inspect --format '{{.Id}} {{.Image}}' mm_bf16_serve_20260907
mkdir "$out/timing"
docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh" timeout --signal=TERM --kill-after=25s 720s torchrun --nproc_per_node=4 --master_addr=127.0.0.1 --master_port=29541 "$task/bench_v31_operator.py" "$out/timing" timing
printf '0
' > "$out/timing.rc"
docker exec mm_bf16_serve_20260907 python3 "$guard"
mkdir "$out/profile"
docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh" timeout --signal=TERM --kill-after=25s 720s msprof --output="$out/msprof" --ascendcl=on --runtime-api=on --task-time=on --ai-core=off torchrun --nproc_per_node=4 --master_addr=127.0.0.1 --master_port=29541 "$task/bench_v31_operator.py" "$out/profile" profile
printf '0
' > "$out/profile.rc"
printf '%s
' V31_OPERATOR_TIMING_AND_NATIVE_PROFILE_COMPLETE
