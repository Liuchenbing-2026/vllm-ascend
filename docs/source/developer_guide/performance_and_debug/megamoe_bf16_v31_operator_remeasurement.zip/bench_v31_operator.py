"""V30 kernel / V31 runtime, derived from the accepted TP4 BF16 chain harness.

Scopes: routed_core excludes input preparation; routed_with_prepare includes it;
full_chain adds a fixed shared partial and final BF16 AllReduce. Shared expert
MLP, overlap with shared experts, attention, router top-k, and scheduling are
excluded. Native msprof data is collected separately from unprofiled timing.
"""
from datetime import timedelta
from pathlib import Path
import json
import os
import statistics
import sys
import time

import torch
import torch.distributed as dist
import torch_npu

from v31_operator_reference import (
    EXPERTS, FULL_CAPACITY, HIDDEN, INTERMEDIATE, MAX_SOURCE_TOKENS, TOPK, WORLD,
    difference, fingerprint, validate_runtime,
)


def main(output, mode):
    vendor, buffer_mb, make_symm, mega_moe, prepare, apply_mlp = validate_runtime()
    rank = int(os.environ['RANK'])
    assert int(os.environ['WORLD_SIZE']) == WORLD
    assert os.environ['ASCEND_RT_VISIBLE_DEVICES'] == '0,1,2,3'
    out = Path(output)
    assert out.is_dir() and not (out / ('complete_rank%d.json' % rank)).exists()
    torch.npu.set_device(rank)
    device = torch.device('npu:%d' % rank)
    options = torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
    options.hccl_config = {'hccl_buffer_size': buffer_mb}
    dist.init_process_group('hccl', timeout=timedelta(seconds=180), pg_options=options)
    dist.all_reduce(torch.ones(8, device=device))
    symm = make_symm(dist.group.WORLD, EXPERTS, MAX_SOURCE_TOKENS + 32, TOPK, HIDDEN,
                     2 * INTERMEDIATE, max_recv_token_num=FULL_CAPACITY,
                     dispatch_quant_mode=0, dispatch_quant_out_dtype=None,
                     comm_alg='local_partial_tp4')
    assert symm.ccl_buffer_size == 2 * buffer_mb * 1024 * 1024
    local_experts = EXPERTS // WORLD
    torch.manual_seed(1024 + rank)
    w1 = (torch.randn(local_experts, HIDDEN, 2 * INTERMEDIATE, dtype=torch.bfloat16) * 0.01).to(device)
    w2 = (torch.randn(local_experts, INTERMEDIATE, HIDDEN, dtype=torch.bfloat16) * 0.01).to(device)
    views1, views2 = list(w1.unbind()), list(w2.unbind())
    weight_sha = fingerprint([w1, w2])
    scopes = ['routed_with_prepare'] if mode == 'profile' else ['routed_core', 'routed_with_prepare', 'full_chain']
    sample_count = 10 if mode == 'profile' else 30
    rows = []
    with torch.inference_mode():
        for tokens in [512, 4096, 6144, 8192]:
            torch.manual_seed(9100 + tokens)
            x = torch.randn(tokens, HIDDEN, dtype=torch.bfloat16).to(device)
            ids = torch.rand(tokens, EXPERTS).topk(TOPK, dim=-1).indices.to(device=device, dtype=torch.int32)
            probs = torch.rand(tokens, TOPK)
            probs = (probs / probs.sum(dim=-1, keepdim=True)).to(device=device, dtype=torch.bfloat16)
            shared = x * (0.01 * (rank + 1))
            input_sha = fingerprint([x, ids, probs])

            def prep_off():
                mask = (ids >= rank * local_experts) & (ids < (rank + 1) * local_experts)
                return probs * mask

            def prep_on():
                # Exactly the V31 production preparation call, including the
                # preapplied mask contract (no scalar CANN active-mask scan).
                return prepare(x.contiguous(), ids.to(torch.int32).contiguous(), probs.contiguous(),
                               None, EXPERTS, 0, 1, preapply_active_mask=True)

            def core_off(routing_probs):
                routed, indices, counts, _ = torch_npu.npu_moe_init_routing_v2(
                    x, ids, active_num=tokens * TOPK, expert_num=EXPERTS,
                    expert_tokens_num_type=1, expert_tokens_num_flag=True,
                    active_expert_range=[rank * local_experts, (rank + 1) * local_experts], quant_mode=-1)
                down, _ = apply_mlp(hidden_states=routed, w1=w1, w2=w2,
                                    group_list=counts.to(torch.int64), group_list_type=1, need_trans=False)
                return torch_npu.npu_moe_token_unpermute(
                    permuted_tokens=down, sorted_indices=torch.abs(indices), probs=routing_probs)

            def core_on(prepared):
                xx, ii, pp, active, original = prepared
                assert original == tokens and active is None
                partial, _ = mega_moe(xx, ii.to(torch.int32), pp.to(torch.float32), views1, views2, symm,
                                     l1_weights_sf=None, l2_weights_sf=None, x_active_mask=active,
                                     weight1_type=None, weight2_type=None)
                return partial[:original]

            def invoke(arm, scope, prepared=None):
                if prepared is None:
                    prepared = prep_off() if arm == 'off' else prep_on()
                value = core_off(prepared) if arm == 'off' else core_on(prepared)
                if scope == 'full_chain':
                    value = value + shared
                    dist.all_reduce(value)
                return value

            for scope in scopes:
                reference = invoke('off', scope)
                candidate = invoke('on', scope)
                torch.npu.synchronize()
                error = difference(candidate, reference)
                assert error['bitwise_equal'], ('PRECISION_DIFFERENCE', tokens, scope, rank, error)
                for arm in ['off', 'on']:
                    queued = [invoke(arm, scope) for _ in range(20)]
                    torch.npu.synchronize()
                    assert all(torch.equal(value, reference) for value in queued), ('ASYNC_REPEAT_DIFFERENCE', tokens, scope)
                    del queued
                row = dict(tokens=tokens, rank=rank, scope=scope, mode=mode, weight_sha256=weight_sha,
                           input_sha256=input_sha, reference_difference=error, async_repeats_each_arm=20, blocks=[])
                print('PRECISION_AND_QUEUED_STABILITY_PASS', tokens, scope, rank, flush=True)
                for label in ['off_A1', 'on_B1', 'on_B2', 'off_A2']:
                    arm = label.split('_')[0]
                    for _ in range(10):
                        invoke(arm, scope)
                    torch.npu.synchronize()
                    samples = []
                    for _ in range(sample_count):
                        dist.barrier()
                        torch.npu.synchronize()
                        prepared = None
                        if scope == 'routed_core':
                            # Refresh mutable inputs outside the measured region.
                            prepared = prep_off() if arm == 'off' else prep_on()
                            torch.npu.synchronize()
                        start = time.perf_counter()
                        value = invoke(arm, scope, prepared)
                        torch.npu.synchronize()
                        samples.append((time.perf_counter() - start) * 1000)
                    assert torch.equal(value, reference), ('POST_TIMING_PRECISION_DIFFERENCE', tokens, scope, label)
                    row['blocks'].append(dict(label=label, samples_ms=samples, median_ms=statistics.median(samples)))
                assert fingerprint([x, ids, probs]) == input_sha, 'SOURCE_INPUT_MUTATED'
                path = out / ('%s_%d_rank%d.json' % (scope, tokens, rank))
                path.write_text(json.dumps(row, indent=2))
                rows.append(row)
                print('OPERATOR_CASE_COMPLETE', tokens, scope, rank,
                      [b['median_ms'] for b in row['blocks']], flush=True)
                dist.barrier()
    maps = [line for line in Path('/proc/self/maps').read_text().splitlines()
            if ('libopapi' in line or 'npu_mega_moe' in line) and '/' in line]
    symm.destroy()
    dist.barrier()
    dist.destroy_process_group()
    (out / ('complete_rank%d.json' % rank)).write_text(json.dumps(dict(
        status='V31_OPERATOR_COMPLETE', rank=rank, cases=len(rows), mode=mode,
        scope=__doc__, vendor=str(vendor), loaded_libraries=sorted(set(line.split()[-1] for line in maps)),
        source_commit='481b9570b7bf83b483f81d1a5450515e5f2a0e4a',
        kernel_commit='23617531fd023f5a90612e6bddb8d21f951af234'), indent=2))


if __name__ == '__main__':
    if sys.argv[1:] == ['--validate-only']:
        validate_runtime()
    else:
        assert len(sys.argv) == 3 and sys.argv[2] in ('timing', 'profile')
        main(sys.argv[1], sys.argv[2])
