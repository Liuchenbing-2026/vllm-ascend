"""Four-rank diagnostic derived from the existing BF16 harness.

This is not model accuracy acceptance or an end-to-end benchmark. It separates
the production OFF routed chain, fallback weight representation, and early
top-k versus rank-partial accumulation before a new integration is designed.
"""

from datetime import timedelta
import hashlib
import json
import os
from pathlib import Path
import sys

import torch
import torch.distributed as dist
import torch_npu


HIDDEN, INTERMEDIATE, EXPERTS, TOPK, WORLD = 2048, 512, 256, 8, 4
MAX_SOURCE_TOKENS = 8192
FULL_CAPACITY = (MAX_SOURCE_TOKENS + 32) * TOPK
VA = Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v31_runtime/vllm-ascend-bf16')
REFERENCE_SHAS = {'tests/e2e/pull_request/one_card/test_megamoe_local_partial_prepare.py': 'b050ae87ae2c53fc25475309a6be8a27d073a3162fff817e000f50b9ee2ade32', 'tests/ut/ops/a2/test_megamoe_local_partial.py': 'bf7e1baaa57b40447e4c06b8feed3ce65dc808ac685ac5a292b6033d6dd98704', 'tests/ut/ops/test_fused_moe.py': '378628ae76bfc3be6fb9f679bd8a16aeb4e1b7178d6eab3829372ceef45d1aed', 'vllm_ascend/ascend_config.py': '7c1f34268237998b6695c11a77a3dfd5164420b1738505f72d2badf561785993', 'vllm_ascend/device/device_op.py': 'c64dc4f693da5c537315fb66c9dd121b16be4ef9a7eaaae45390d1871760ba1d', 'vllm_ascend/ops/fused_moe/fused_moe.py': '76142926fb9d9cecbba198e8ea6bb07d8654b0a25658c3bff5ca7b258527d18d', 'vllm_ascend/ops/fused_moe/moe_comm_method.py': '204c402634fda963d8910c3e18096d25b4143c930ba18f07244e50e90591b50c', 'vllm_ascend/ops/fused_moe/moe_mlp.py': '6236894da2ad643df88e826431cee0febbdf27f56159308be47cfca03e3baa34', 'vllm_ascend/ops/fused_moe/prepare_finalize.py': 'fd0d34a922a540753816ef98af9227fe09b131131e445b791c18d545068b8fc4', 'vllm_ascend/ops/fused_moe/routed_experts.py': 'a444b708eb6b607410abc7739431e3fdbe741dd6f44265aa588a18d138cb3181', 'vllm_ascend/ops/fused_moe/token_dispatcher.py': '383a4c1d6d56ea2e9e7e85e51d7e2ac2070ab40fec65b122e19f95aa9fbe19b8', 'vllm_ascend/ops/triton/megamoe_prepare.py': 'ac38fa1acf594be840021705824c88307842eeed45e84e82b2f4dc91ba8a8891', 'vllm_ascend/utils.py': 'cfb93a25a0427d0dd459088c8b90cfc221b2c409b94cd4ac99c9b3f5ebdd1582'}


def fingerprint(tensors):
    digest = hashlib.sha256()
    for tensor in tensors:
        cpu = tensor.detach().cpu().contiguous()
        digest.update(str((tuple(cpu.shape), cpu.dtype)).encode())
        digest.update(cpu.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def difference(actual, expected):
    actual = actual.detach().cpu().contiguous()
    expected = expected.detach().cpu().contiguous()
    assert actual.shape == expected.shape and actual.dtype == expected.dtype == torch.bfloat16
    assert torch.isfinite(actual).all() and torch.isfinite(expected).all()
    err = actual.float() - expected.float()
    unequal = actual.view(torch.int16) != expected.view(torch.int16)
    indices = unequal.nonzero()[:8]
    return dict(
        bitwise_equal=bool(not unequal.any()),
        unequal_elements=int(unequal.sum()),
        elements=actual.numel(),
        max_abs=float(err.abs().max()),
        relative_l2=float(err.double().norm() / expected.double().norm().clamp_min(1e-20)),
        examples=[dict(index=i.tolist(), actual=float(actual[tuple(i)]), expected=float(expected[tuple(i)])) for i in indices],
    )


def validate_runtime():
    assert not torch.npu.is_initialized()
    vendor = Path(os.environ['MMGAIN_EXPECTED_VENDOR'])
    expected_path = os.environ['ASCEND_CUSTOM_OPP_PATH']
    assert expected_path.split(':')[0] == str(vendor)
    for name, expected in REFERENCE_SHAS.items():
        assert hashlib.sha256((VA / name).read_bytes()).hexdigest() == expected, name
    kernel = vendor / 'op_impl/ai_core/tbe/kernel/ascend910b/mega_moe/MegaMoe_d95b9716a3c9814f6ca27f3b4f54fc18.o'
    assert hashlib.sha256(kernel.read_bytes()).hexdigest() == os.environ['MMGAIN_EXPECTED_ND_SHA']
    # Follow the already accepted harness's import/bootstrap order.
    import vllm_ascend.utils as vu
    vu.bootstrap_custom_op_env()
    import vllm_ascend.vllm_ascend_C
    from cann_ops_transformer.ops.mega_moe import (
        _get_mega_moe_ccl_buffer_size,
        get_symm_buffer_for_mega_moe,
        mega_moe,
    )
    from vllm_ascend.ops.fused_moe.moe_comm_method import _append_cann_megamoe_dummy_tokens
    from vllm_ascend.ops.fused_moe.moe_mlp import unquant_apply_mlp
    assert os.environ['ASCEND_CUSTOM_OPP_PATH'] == expected_path
    assert not torch.npu.is_initialized()
    assert Path(vu.__file__).resolve() == (VA / 'vllm_ascend/utils.py').resolve()
    # The new output layout uses full replicated input, with explicit capacity
    # for every real and sentinel assignment. The isolated C++ query enforces it.
    buffer_mb = int(_get_mega_moe_ccl_buffer_size(
        WORLD, EXPERTS, MAX_SOURCE_TOKENS + 32, TOPK, HIDDEN,
        max_recv_token_num=FULL_CAPACITY, dispatch_quant_mode=0,
        dispatch_quant_out_dtype=None, comm_alg='local_partial_tp4',
    ))
    extension = json.loads(Path(os.environ['MMGAIN_EXPECTED_EXTENSION_MANIFEST']).read_text())
    assert extension['status'] == 'PASS' and extension['source_commit'] == 'a97d4ace25f5f8a51ca4584ebab941249022d5c7'
    assert buffer_mb == extension['buffer_mb'] and not torch.npu.is_initialized()
    from cann_ops_transformer.ops.mega_moe import _mega_moe_op_builder
    binary = Path(_mega_moe_op_builder.load().__file__)
    assert str(binary) == extension['binary']
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == extension['sha256']
    print('CPU_REFERENCE_AND_BUFFER_GATE_PASS', buffer_mb, flush=True)
    from vllm_ascend.ops.triton.megamoe_prepare import prepare_cann_megamoe_local_partial
    assert not torch.npu.is_initialized()
    return vendor, buffer_mb, get_symm_buffer_for_mega_moe, mega_moe, prepare_cann_megamoe_local_partial, unquant_apply_mlp

