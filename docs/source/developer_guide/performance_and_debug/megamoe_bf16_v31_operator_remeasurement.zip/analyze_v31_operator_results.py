"""Analyze the existing msprof op_summary records and unprofiled ABBA samples."""
from pathlib import Path
import base64
import gzip
import hashlib
import json
import re
import statistics
import sys

root = Path(__file__).resolve().parent
tag = int(sys.argv[1])
receipt = root.parent / 'direct_receipts' / ('mmgain_20260907_bf16_e2e_%d.out' % tag)
text = receipt.read_text(encoding='utf-8')
line = next(line for line in text.splitlines() if line.startswith('V31_OPERATOR_RESULTS_JSON '))
raw = gzip.decompress(base64.b64decode(line.split(' ', 1)[1]))
observation = json.loads(next(line for line in text.splitlines() if line.startswith('V31_OPERATOR_OBSERVATION ')).split(' ',1)[1])
assert hashlib.sha256(raw).hexdigest() == observation['raw_sha256']
data = json.loads(raw)
target = root / 'v31_operator_raw_results.json'
if target.exists():assert target.read_bytes() == raw
else:target.write_bytes(raw)
selected = list(range(31,41)) + list(range(51,61))
native_rows = []
for device in data['native']:
    shapes = {s['id']:s for s in device['shapes']}
    tasks = device['tasks']
    def op(task):return shapes[task['shape_id']]['op']
    def first_dim(task, output=False, tensor_index=0):
        value = shapes[task['shape_id']]['output_shapes' if output else 'input_shapes']
        value = value.strip('"').split(';')[tensor_index]
        match = re.search(r'\d+', value)
        assert match, ('SHAPE_MISSING', op(task), value)
        return int(match.group())
    for tokens in data['manifest']['input_tokens']:
        # CANN emits V3 for the Python V2 API; MegaMoe input 0 is context,
        # while its hidden tensor is input 1. Match the observed native schema.
        route = [t for t in tasks if op(t)=='MoeInitRoutingV3' and first_dim(t)==tokens]
        unpermute = [t for t in tasks if op(t)=='MoeTokenUnpermute' and first_dim(t,True)==tokens]
        mega = [t for t in tasks if op(t)=='MegaMoe' and first_dim(t,tensor_index=1)==tokens+32]
        assert len(route)==len(unpermute)==len(mega)==61, ('EXPECTED_61_CALLS',device['device'],tokens,len(route),len(unpermute),len(mega))
        metrics = {k:[] for k in ['off_span_us','off_named_tasks_sum_us','on_mega_us','off_route_us','off_gmm1_us','off_swiglu_us','off_gmm2_us','off_unpermute_us','off_other_tasks_us','off_idle_us']}
        for index in selected:
            first,last = route[index],unpermute[index]
            assert first['stream_id']==last['stream_id']
            finish = last['start_us']+last['duration_us']
            inside = [t for t in tasks if t['stream_id']==first['stream_id'] and first['start_us']<=t['start_us']<finish]
            gmms = [t for t in inside if op(t)=='GroupedMatmul']
            act = [t for t in inside if op(t)=='SwiGlu']
            assert len(gmms)==2 and len(act)==1, ('CORE_SEQUENCE_MISMATCH',device['device'],tokens,index,[(op(t),t['duration_us']) for t in inside])
            sequence = [first,gmms[0],act[0],gmms[1],last]
            assert all(b['start_us']+0.3>=a['start_us']+a['duration_us'] for a,b in zip(sequence,sequence[1:]))
            span = finish-first['start_us']
            named = sum(t['duration_us'] for t in sequence)
            busy = sum(t['duration_us'] for t in inside)
            assert span+1>=busy, ('OVERLAPPING_MAIN_STREAM_TASKS',device['device'],tokens,index)
            metrics['off_span_us'].append(span)
            metrics['off_named_tasks_sum_us'].append(named)
            metrics['on_mega_us'].append(mega[index]['duration_us'])
            metrics['off_other_tasks_us'].append(busy-named)
            metrics['off_idle_us'].append(max(0,span-busy))
            for key,task in zip(['off_route_us','off_gmm1_us','off_swiglu_us','off_gmm2_us','off_unpermute_us'],sequence):
                metrics[key].append(task['duration_us'])
        medians = {k:statistics.median(v) for k,v in metrics.items()}
        native_rows.append(dict(device=device['device'],tokens=tokens,median_us=medians,samples_us=metrics,
                                mega_vs_off_span_percent=(medians['on_mega_us']/medians['off_span_us']-1)*100,
                                mega_vs_off_named_tasks_percent=(medians['on_mega_us']/medians['off_named_tasks_sum_us']-1)*100))
native_aggregate=[]
for tokens in data['manifest']['input_tokens']:
    rows=[r for r in native_rows if r['tokens']==tokens]
    assert {r['device'] for r in rows}=={0,1,2,3}
    # Keep the four ranks and both ABBA blocks explicit, as in host timing.
    blocks=[]
    for block in range(2):
        off=[max(r['samples_us']['off_span_us'][i] for r in rows) for i in range(block*10,(block+1)*10)]
        on=[max(r['samples_us']['on_mega_us'][i] for r in rows) for i in range(block*10,(block+1)*10)]
        blocks.append(dict(off_span_us=statistics.median(off),on_mega_us=statistics.median(on)))
    off=statistics.mean(b['off_span_us'] for b in blocks)
    on=statistics.mean(b['on_mega_us'] for b in blocks)
    native_aggregate.append(dict(tokens=tokens,off_span_us=off,on_mega_us=on,latency_change_percent=(on/off-1)*100,blocks=blocks))
result=dict(status='V31_OPERATOR_REMEASUREMENT_ANALYZED',source_raw_sha256=hashlib.sha256(raw).hexdigest(),
            manifest=data['manifest'],unprofiled=data['comparisons'],native=native_rows,native_aggregate=native_aggregate,
            precision=dict(cases=48,local_cases=32,final_cases=16,bitwise_equal=True,queued_repeats_each_arm=20),
            interpretation='Native OFF span is routing start through unpermute end on the same stream, including required intermediate tasks and launch gaps. ON is the MegaMoe task duration. Four-rank slowest-per-index aggregation and mean of two block medians. Native run is profiled; unprofiled host timings are reported separately. These synthetic cases exclude shared expert computation, overlap, attention, top-k selection, and scheduling.')
target=root/'v31_operator_remeasurement_summary.json'
assert not target.exists()
target.write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
for row in data['comparisons']:
    print('UNPROFILED',json.dumps({k:v for k,v in row.items() if k!='blocks'}))
for row in native_aggregate:print('NATIVE_FOUR_RANK',json.dumps(row))
for row in native_rows:print('NATIVE_RANK',json.dumps({k:v for k,v in row.items() if k!='samples_us'}))
print('V31_OPERATOR_ANALYSIS_PASS',target)
