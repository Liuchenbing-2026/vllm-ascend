from pathlib import Path
import hashlib,json,re,socket,subprocess

t=Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v31_overlap')
text=subprocess.check_output(['npu-smi','info'],universal_newlines=True)
memory=[int(x) for x in re.findall(r'(\d+)\s*/\s*65536',text)]
assert len(memory)==8
selected=[0,1,2,3]
assert all(memory[i]<6000 and 'No running processes found in NPU %d'%i in text for i in selected),('SELECTED_DEVICE_BUSY',memory)
for port in [8001,29541]:
    with socket.socket() as s:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s.bind(('0.0.0.0',port))
for row in json.loads((t/'source_manifest.json').read_text())['files']:
    assert hashlib.sha256((Path('/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v31_runtime/vllm-ascend-bf16')/row['path']).read_bytes()).hexdigest()==row['sha256']
model=json.loads((t/'model_ready.json').read_text())
assert model['status']=='PASS' and model['tensor_dtypes']=={'BF16':1045}
for row in model['files']:
    p=Path(row['path']);assert p.stat().st_size==row['size'] and p.stat().st_mtime_ns==row['mtime_ns'], 'MODEL_CHANGED_AFTER_SHA_VERIFICATION'
print('SELECTED_FOUR_DEVICES_PORTS_AND_SOURCE_CLEAR',selected,memory,flush=True)

def blocks_new_server(state,comm,args):
    if state in ('Z','X'):return False
    return comm.startswith('VLLM') or any(Path(x.decode(errors='replace')).name=='vllm' for x in args if x)

for p in Path('/proc').iterdir():
    if not p.name.isdigit():continue
    try:
        comm=(p/'comm').read_text().strip()
        fields=(p/'stat').read_text().rsplit(')',1)[1].split()
        args=(p/'cmdline').read_bytes().split(bytes([0]))
        assert not blocks_new_server(fields[0],comm,args), ('EXISTING_LIVE_VLLM_PROCESS',p.name,fields[0],comm)
    except (FileNotFoundError,ProcessLookupError):pass
