"""Existing 4096-token prefill probe with response and repeatability gates."""
import json
from pathlib import Path
import statistics
import sys
import time
import urllib.request

port, out = int(sys.argv[1]), Path(sys.argv[2])
model = 'Qwen36'
base = f'http://127.0.0.1:{port}'
out.mkdir(parents=True, exist_ok=True)


def request(endpoint, payload):
    payload=dict(payload,seed=1024)
    req = urllib.request.Request(base + endpoint, data=json.dumps(payload).encode(),
                                 headers={'Content-Type': 'application/json'})
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=180) as r:
        result = json.loads(r.read())
    assert result.get('choices') and result.get('usage'), result
    return (time.perf_counter() - t0) * 1000, result


def completion(seed, count):
    ids = [((seed * 7919 + i * 31) % 90000) + 1000 for i in range(4096)]
    ms, result = request('/v1/completions', dict(model=model, prompt=ids, max_tokens=count,
                                               temperature=0.0, stream=False, ignore_eos=True))
    assert result['usage']['prompt_tokens'] == 4096
    assert result['usage']['completion_tokens'] == count
    return ms, result


with urllib.request.urlopen(base + '/health', timeout=10) as r:
    assert r.status == 200

_, short = request('/v1/chat/completions', dict(
    model=model, messages=[{'role': 'user', 'content': 'Reply with exactly the number 42.'}],
    max_tokens=32, temperature=0.0, chat_template_kwargs={'enable_thinking': False}))
(out / 'short_response.json').write_text(json.dumps(short, indent=2))
text = short['choices'][0]['message']['content']
assert text is not None and '42' in text, ('SHORT_REQUEST_INCORRECT', short)

# A second token length distinguishes an initial-shape effect from stable decoding.
responses_2k = []
ids_2k = [((777 * 7919 + i * 31) % 90000) + 1000 for i in range(2048)]
for _ in range(3):
    _, result = request('/v1/completions', dict(model=model, prompt=ids_2k, max_tokens=32,
                                              temperature=0.0, stream=False, ignore_eos=True, logprobs=2))
    responses_2k.append(result)
    (out / 'stability_2k.json').write_text(json.dumps(responses_2k, indent=2))
assert len({x['choices'][0]['text'] for x in responses_2k}) == 1, 'TWO_K_OUTPUT_UNSTABLE'
probabilities = [x['choices'][0]['logprobs']['top_logprobs'] for x in responses_2k]
print('TWO_K_TEXT_STABILITY_PASS', flush=True)
print('TWO_K_TOP_LOGPROBS_IDENTICAL', all(x == probabilities[0] for x in probabilities), flush=True)
print('DIAGNOSTIC_ONLY_NO_PERFORMANCE', flush=True)

reference = Path(__file__).resolve().parent / 'golden'
prior = json.loads((reference / 'stability_2k.json').read_text())
comparison = dict(
    text_equal=responses_2k[0]['choices'][0]['text'] == prior[0]['choices'][0]['text'],
    logprobs_equal=responses_2k[0]['choices'][0]['logprobs'] == prior[0]['choices'][0]['logprobs'])
(out / 'cross_off_2k.json').write_text(json.dumps(comparison, indent=2))
assert all(comparison.values()), ('OFF_2K_PRECISION_MISMATCH', comparison)
print('OFF_2K_TEXT_AND_LOGPROBS_EXACT_PASS', flush=True)
stable = []
for _ in range(3):
    stable.append(completion(777, 32)[1])
    (out / 'correctness.json').write_text(json.dumps({'short': short, 'long_repeats': stable}, indent=2))
texts = [r['choices'][0]['text'] for r in stable]
assert len(set(texts)) == 1, 'LONG_PREFILL_OUTPUT_UNSTABLE'
out.mkdir(parents=True, exist_ok=True)
(out / 'correctness.json').write_text(json.dumps({'short': short, 'long_repeats': stable}, indent=2))
print('SERVICE_CORRECTNESS_AND_STABILITY_PASS', flush=True)


prior4 = json.loads((reference / 'correctness.json').read_text())['long_repeats']
same4 = stable[0]['choices'][0]['text'] == prior4[0]['choices'][0]['text']
(out / 'cross_off_4k.json').write_text(json.dumps(dict(text_equal=same4)))
assert same4, 'OFF_4K_TEXT_MISMATCH'
print('OFF_4K_TEXT_EXACT_PASS', flush=True)

# Extend the existing request/repeat probe to the workload and padding boundaries.
extended = {}
for length in (511, 513, 6144):
    rows = []
    ids = [((777 * 7919 + i * 31) % 90000) + 1000 for i in range(length)]
    for repeat in range(3):
        _, response = request('/v1/completions', dict(model=model, prompt=ids, max_tokens=32,
            temperature=0.0, stream=False, ignore_eos=True, logprobs=2))
        assert response['usage']['prompt_tokens'] == length
        assert response['usage']['completion_tokens'] == 32
        rows.append(response)
        extended[str(length)] = rows
        (out/'extended_precision.json').write_text(json.dumps(extended,indent=2))
    choices = [x['choices'][0] for x in rows]
    assert all(c['text'] == choices[0]['text'] and c['logprobs'] == choices[0]['logprobs'] for c in choices), ('EXTENDED_REPEAT_MISMATCH',length)
    if out.parent.name.startswith('on_'):
        reference_path = out.parent.parent/'off_user_A1/probe/extended_precision.json'
        ref = json.loads(reference_path.read_text())[str(length)][0]['choices'][0]
        same = dict(text_equal=choices[0]['text']==ref['text'],logprobs_equal=choices[0]['logprobs']==ref['logprobs'])
        (out/('cross_off_'+str(length)+'.json')).write_text(json.dumps(same))
        assert all(same.values()), ('EXTENDED_OFF_PRECISION_MISMATCH',length,same)
    print('EXTENDED_PRECISION_PASS',length,flush=True)
