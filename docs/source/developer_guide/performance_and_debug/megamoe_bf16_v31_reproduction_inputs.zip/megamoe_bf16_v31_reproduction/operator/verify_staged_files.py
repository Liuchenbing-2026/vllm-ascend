from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for name,want in manifest['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==want,name
print('STAGED_DIAGNOSTIC_FILES_PASS')
