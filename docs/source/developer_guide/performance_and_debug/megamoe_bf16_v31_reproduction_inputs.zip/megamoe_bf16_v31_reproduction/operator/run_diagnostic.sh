#!/usr/bin/env bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_e2e_20260907/tp4_local_partial_v30_edges
profile=/data1/megamoe_gain_20260905/bf16_e2e_20260907/user_tp4_v29_native
test "$(cat "$task/static.rc")" = 0
test "$(cat "$profile/results/on_P1/stop.rc")" = 0
test -f "$profile/export_parallel_resume_20260912/original_controller_terminal.json"
exec 9>/var/lock/megamoe_q36.lock
flock -n 9
python3 "$task/verify_staged_files.py"
docker exec mm_bf16_serve_20260907 python3 "$profile/preflight_devices.py"
out=$task/run_A1
test ! -e "$out"
mkdir "$out"
exec > "$out/run.log" 2>&1
printf '%s
' "$$" > "$out/launcher.pid"
cat /proc/$$/stat > "$out/launcher.initial_stat"
on_exit() {
  rc=$?
  trap - EXIT
  set +e
  printf '%s
' "$rc" > "$out/run.rc"
  docker exec mm_bf16_serve_20260907 python3 "$profile/preflight_devices.py" > "$out/postflight.log" 2>&1
  post_rc=$?
  printf '%s
' "$post_rc" > "$out/postflight.rc"
  if test "$rc" = 0 && test "$post_rc" != 0; then rc=$post_rc; fi
  printf '%s
' "$rc" > "$out/controller.rc"
  exit "$rc"
}
trap on_exit EXIT
docker exec mm_bf16_serve_20260907 python3 "$profile/preflight_devices.py"
docker inspect --format '{{.Id}} {{.Image}}' mm_bf16_serve_20260907
docker exec mm_bf16_serve_20260907 bash "$task/run_env.sh"   timeout --signal=TERM --kill-after=25s 480s   torchrun --nproc_per_node=4 --master_addr=127.0.0.1 --master_port=29541   "$task/bench_tp4_local_partial_edges.py" "$out"
printf '%s
' FOUR_RANK_PRECISION_DIAGNOSTIC_FINISHED_NOT_MODEL_ACCEPTANCE
