# 2026-09-13 delivery replay on 183.236.60.18

The two replay directories contain all eight raw bench result JSONs, commands,
precision outputs, service identities, source/binary hashes, and cleanup receipts.
Only the MegaMoe configuration differs between OFF and ON. Profile/CI work was
excluded from timing. Four-card BF16; 4096/6144 input, 256 output, C32, 160 requests.

Recompute from this directory with the existing collector outputs:

```bash
python3 summary/summarize_delivery_abba.py \
  bf16_repro_v31_off_on_prepared_20260913/collected_results.log \
  bf16_repro_v31_on_off_prepared_20260913/collected_results.log \
  --output recomputed_abba.json
```

Mean throughput improved 0.858% (4K) / 1.475% (6K). Mean TTFT changed
+5.251% (4K, slower) / -2.643% (6K, faster). The prior 4K TTFT benefit
did not reproduce. Fixed correctness/repeat checks passed; this is not proof
of losslessness on all model inputs or a statistical significance claim.

The full runtime source closure matches 553 tracked framework files to the
exact source archive. See prior_source_validation/full_runtime_source_closure.json.
Build commands and source provenance are under build_provenance/.
