"""Summarize validated OFF/ON and ON/OFF logs produced by collect_results.sh."""

import argparse
import hashlib
import json
import statistics
from pathlib import Path


def read_pair(path):
    marker = "V31_CONTROLLED_PAIR_JSON "
    lines = [line for line in path.read_text(encoding="utf-8").splitlines() if line.startswith(marker)]
    assert len(lines) == 1, (path, "Expected one validated pair")
    return json.loads(lines[0][len(marker):])


def summarize(paths):
    reports = [read_pair(path) for path in paths]
    assert reports[0]["status"] == "V31_FIRST_CONTROLLED_PAIR_COLLECTED"
    assert reports[1]["status"] == "V31_REVERSE_CONTROLLED_PAIR_COLLECTED"
    for key in ["source_commit", "kernel_source_commit", "binaries", "baseline_container", "baseline_image"]:
        assert reports[0]["manifest"][key] == reports[1]["manifest"][key], key
    settings = reports[0]["effective_settings"]
    assert settings == reports[1]["effective_settings"]
    assert settings == dict(
        input_lengths=[4096, 6144], output_length=256, concurrency=32,
        requests_per_length=160, seed=1024, temperature=0,
        profiling=False, shared_overlap=True,
    )
    assert all(report["extended_precision_exact"] for report in reports)
    arms = [["off_user_A1", "on_B1"], ["off_user_A2", "on_B2"]]
    for mode in range(2):
        first, second = arms[0][mode], arms[1][mode]
        configs = [dict(reports[0]["configs"][first]), dict(reports[1]["configs"][second])]
        for config in configs:
            config["workers"] = sorted(config["workers"])
        assert configs[0] == configs[1], "Configuration differs between matched arms"
        for key in ["command", "environment"]:
            assert reports[0]["identities"][first][key] == reports[1]["identities"][second][key], key
    for length in ["4096", "6144"]:
        reference = reports[0]["records"]["off_user_A1"][length]
        assert len(reference["input_lens"]) == len(reference["output_lens"]) == 160
        assert set(reference["output_lens"]) == {256}
        for report, pair in zip(reports, arms):
            for arm in pair:
                record = report["records"][arm][length]
                assert record["input_lens"] == reference["input_lens"]
                assert record["output_lens"] == reference["output_lens"]
                assert report["acceptance"][arm]["status"] == "PASS"
    rows = []
    for length in [4096, 6144]:
        pairs = [next(row for row in report["comparisons"] if row["input_requested"] == length) for report in reports]
        row = dict(input_requested=length)
        for metric in ["output_throughput", "mean_ttft_ms", "mean_tpot_ms", "duration"]:
            off = [pair[metric]["off"] for pair in pairs]
            on = [pair[metric]["on"] for pair in pairs]
            assert all(isinstance(value, (int, float)) and value > 0 for value in off + on)
            off_mean, on_mean = statistics.mean(off), statistics.mean(on)
            changes = [(b / a - 1) * 100 for a, b in zip(off, on)]
            row[metric] = dict(
                off_rounds=off, on_rounds=on, off_mean=off_mean, on_mean=on_mean,
                change_percent=(on_mean / off_mean - 1) * 100, pair_changes_percent=changes,
            )
        throughput = row["output_throughput"]
        row["both_pairs_exceed_practical_margin"] = all(value >= 0.2 for value in throughput["pair_changes_percent"])
        row["on_min_exceeds_off_max"] = min(throughput["on_rounds"]) > max(throughput["off_rounds"])
        row["ttft_both_pairs_lower"] = all(value < 0 for value in row["mean_ttft_ms"]["pair_changes_percent"])
        rows.append(row)
    return dict(
        status="CONTROLLED_ABBA_SUMMARY_COMPLETE",
        throughput_gain_reproduced=all(row["both_pairs_exceed_practical_margin"] and row["on_min_exceeds_off_max"] for row in rows),
        practical_margin_percent=0.2,
        order=["off_user_A1", "on_B1", "on_B2", "off_user_A2"],
        settings=settings, comparisons=rows,
        source_commit=reports[0]["manifest"]["source_commit"],
        kernel_commit=reports[0]["manifest"]["kernel_source_commit"],
        input_logs=[dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in paths],
        precision="Fixed text/logprobs and repeated requests passed in all four arms; not an all-input losslessness proof.",
        caution="Two OFF and two ON samples. The 0.2% practical check is not a statistical significance test or a guarantee for other environments.",
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("off_on_log", type=Path)
    parser.add_argument("on_off_log", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = summarize([args.off_on_log, args.on_off_log])
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8", newline="\n") as file:
            file.write(text)
    print(text, end="")
