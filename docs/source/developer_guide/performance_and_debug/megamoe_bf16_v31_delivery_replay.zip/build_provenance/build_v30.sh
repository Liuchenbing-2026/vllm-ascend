#!/usr/bin/env bash
set -eo pipefail
root=/data1/megamoe_gain_20260905/bf16_opt_20260907
exec > "$root/results/build_v30.log" 2>&1
trap 'rc=$?; printf "%s\n" "$rc" > "$root/results/build_v30.rc"' EXIT
source /usr/local/Ascend/ascend-toolkit/set_env.sh
export PATH=/usr/local/Ascend/cann-9.1.0/tools/bisheng_compiler/bin:$PATH
export CMAKE_BUILD_PARALLEL_LEVEL=32
unset OMP_NUM_THREADS
export GIT_CONFIG_COUNT=1
export GIT_CONFIG_KEY_0=submodule.include/tensor_api.update
export GIT_CONFIG_VALUE_0=none
cd "$root/source_v30"
printf '%s\n' BUILD_BF16_V30_SOURCE_MANIFEST
cat "$root/source_v30_manifest.json"
sha256sum mc2/mega_moe/op_kernel/arch22/mega_moe_kernel_a2_bf16.hpp
bash build.sh --pkg --soc=ascend910b --ops=mega_moe --vendor_name=mmbf16v30 -j32
printf '%s\n' BUILD_COMPLETE
