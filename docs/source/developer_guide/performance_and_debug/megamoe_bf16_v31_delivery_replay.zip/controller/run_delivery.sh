#!/usr/bin/env bash
set -euo pipefail
root=/data1/megamoe_gain_20260905/bf16_e2e_20260907/v31_delivery_replay_20260913
base=/data1/megamoe_gain_20260905/bf16_e2e_20260907
exec > "$root/controller.log" 2>&1
cleanup() {
  rc=$?
  trap - EXIT
  printf '%s\n' "$rc" > "$root/controller.rc"
  set +e
  docker exec mm_bf16_serve_20260907 python3 "$base/user_tp4_v31_overlap/preflight_devices.py" > "$root/postflight.log" 2>&1
  printf '%s\n' "$?" > "$root/postflight.rc"
  exit "$rc"
}
trap cleanup EXIT
for work in bf16_repro_v31_off_on_prepared_20260913 bf16_repro_v31_on_off_prepared_20260913; do
  printf '%s\n' "$work" > "$root/current_work.txt"
  bash "$base/$work/run_performance.sh"
  bash "$base/$work/collect_results.sh" > "$base/$work/collected_results.log"
done
printf '%s\n' DELIVERY_ABBA_REPLAY_COMPLETE > "$root/progress.txt"
