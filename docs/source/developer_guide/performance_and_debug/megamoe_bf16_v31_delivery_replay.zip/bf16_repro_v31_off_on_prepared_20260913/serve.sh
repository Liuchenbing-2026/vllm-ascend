#!/usr/bin/env bash
set -euo pipefail
task=/data1/megamoe_gain_20260905/bf16_e2e_20260907/bf16_repro_v31_off_on_prepared_20260913
arm=$1
phase=$2
[[ "$arm" =~ ^(off_user|off_nooverlap|on)_[A-Z][0-9]+$ ]]
[[ "$phase" = performance || "$phase" = profile ]]
test "$(cat "$task/static.rc")" = 0
python3 "$task/preflight_devices.py"
out=$task/results/$arm
test ! -e "$out"
mkdir -p "$out"
exec > "$out/server.log" 2>&1
printf '%s\n' "$$" > "$out/server.pid"
cat /proc/$$/stat > "$out/server.initial_stat"
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
set -u
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3
export HCCL_IF_IP=183.236.60.18
export GLOO_SOCKET_IFNAME=enp189s0f0
export TP_SOCKET_IFNAME=enp189s0f0
export HCCL_SOCKET_IFNAME=enp189s0f0
export HCCL_OP_EXPANSION_MODE=AIV
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export HCCL_BUFFSIZE=1024
export OMP_NUM_THREADS=100
export TASK_QUEUE_ENABLE=1
export VLLM_RPC_TIMEOUT=300000
export VLLM_ASCEND_BALANCE_SCHEDULING=1
export HCCL_DETERMINISTIC=true
export LD_PRELOAD=/usr/lib/aarch64-linux-gnu/libjemalloc.so.2${LD_PRELOAD:+:$LD_PRELOAD}
vend=/data1/megamoe_gain_20260905/bf16_opt_20260907/package_v30/packages/vendors/mmbf16v30_transformer
va=/data1/megamoe_gain_20260905/bf16_e2e_20260907/model_v31_runtime/vllm-ascend-bf16
export ASCEND_CUSTOM_OPP_PATH="$vend:$va/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
export LD_LIBRARY_PATH="$vend/op_api/lib:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$va:/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extension_v26:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=/data1/megamoe_gain_20260905/bf16_opt_20260907/torch_extensions_v26
export VLLM_CACHE_ROOT=$task/vllm_cache
export VLLM_USE_V2_MODEL_RUNNER=0
export MEGAMOE_SKIP_COMPILED=0
unset VLLM_ASCEND_ENABLE_FLASHCOMM1 PROFILING_MODE HCCL_CONNECT_TIMEOUT HCCL_EXEC_TIMEOUT OMP_PROC_BIND
if [[ "$phase" = profile ]]; then export PROFILING_MODE=dynamic;fi
mode=${arm%_*}
export MEGAMOE=0
if [[ "$mode" = on ]]; then export MEGAMOE=1;fi
additional_config=$(python3 -c 'import json,sys;print(json.dumps(json.load(open(sys.argv[1]))[sys.argv[2]]))' "$task/configs.json" "$mode")
exec vllm serve /data2/weights/Qwen3.6-35B-A3B \
  --served-model-name Qwen36 --host 0.0.0.0 --port 8001 \
  --tensor-parallel-size 4 --data-parallel-size 1 --pipeline-parallel-size 1 --prefill-context-parallel-size 1 \
  --max-num-seqs 32 --max-model-len 131072 --max-num-batched-tokens 8192 \
  --gpu-memory-utilization 0.90 --dtype bfloat16 --seed 1024 \
  --async-scheduling --trust-remote-code --enable-expert-parallel --enable-prompt-tokens-details \
  --no-enable-prefix-caching --reasoning-parser qwen3 --enable-auto-tool-choice --tool-call-parser qwen3_coder \
  --enable-chunked-prefill --mamba-ssm-cache-dtype bfloat16 \
  --compilation-config '{"cudagraph_mode":"FULL_DECODE_ONLY"}' --additional-config "$additional_config"
