from pathlib import Path
import sys
r=Path(sys.argv[1]);pid=int((r/'server.pid').read_text())
def stat(t):return t[t.rfind(')')+2:].split()
old=stat((r/'server.initial_stat').read_text());p=Path('/proc/%d/stat'%pid)
assert p.exists(), 'OWNED_LAUNCHER_EXITED_BEFORE_READY'
cur=stat(p.read_text());assert old[19]==cur[19] and cur[0] not in ('Z','X'), 'OWNED_LAUNCHER_NO_LONGER_LIVE'
