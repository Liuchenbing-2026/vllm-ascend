# 四卡 BF16 V31 对照证据

paired_summary.json 保存两次 OFF、两次 ON 的均值及正反序变化；两个 pair 文件保存实际命令、配置、输入输出长度、精度验收和原始结果哈希。绝对路径是原始运行位置，复核本包请按这里的文件名读取。

双方 shared overlap=true。首轮原始 manifest 的摘要字段曾遗留 false，原始记录保持原样；off_on_pair.json 的 manifest_metadata_corrections 明确记录勘误，effective_settings 来自已核对的实际命令、配置和运行日志。反序清单与实际配置一致。

operator_v30_bitwise.json 是保持不变的 V30 内核四卡 14 类、56 个 case/rank 的精度证据。V31 调度修改另外通过每轮模型固定文本/logprobs、三次重复及语义检查。有限输入不能证明所有输入的整模型无损，未完成 BF16 全量 GSM8K。

CPU 回执为 225 项通过且未初始化 NPU。完整提交 CI 在原生 Windows 工具环境中未通过，不作为已通过项目。性能期间没有 profiling；结果只适用于本包的当前四卡、BF16、4K/6K、256 输出、并发 32 配置。0.2% 为此前声明的实用重复性门槛，不是统计显著性或跨环境性能保证。
